1#Admin default password: admin123
import json
import os
from datetime import datetime, timedelta

DATA_FILE = "donors.json"
ADMIN_PASSWORD = "admin123"
ELIGIBLE_DAYS = 30  # donor available if last donation was >= 30 days


# ------------------ File Handling ------------------ #
def load_donors(filename=DATA_FILE):
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
            # If file empty or malformed, return empty list
            if not isinstance(data, list):
                return []
            return data
    except (json.JSONDecodeError, IOError):
        print("Warning: Could not read donors file or file corrupted. Starting with empty list.")
        return []


def save_donors(donors, filename=DATA_FILE):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(donors, f, indent=4)
    except IOError as e:
        print("Error saving donors:", e)


# ------------------ Utility Helpers ------------------ #
def parse_date(date_str):
    """Parse YYYY-MM-DD to datetime.date. Return None if invalid."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return None


def is_available(last_donation_str):
    """Check if donor is eligible (>= ELIGIBLE_DAYS days since last donation)."""
    d = parse_date(last_donation_str)
    if not d:
        return False
    return (datetime.today().date() - d) >= timedelta(days=ELIGIBLE_DAYS)


def pretty_print_donor(d, idx=None):
    avail = "AVAILABLE" if is_available(d.get("last_donation", "")) else "NOT AVAILABLE"
    idx_str = f"{idx+1}. " if idx is not None else ""
    print(f"{idx_str}Name: {d.get('name', '')} | BG: {d.get('blood_group', '')} | City: {d.get('city', '')} | "
          f"Contact: {d.get('contact', '')} | Last Donation: {d.get('last_donation', '')} | {avail}")


def input_nonempty(prompt):
    while True:
        v = input(prompt).strip()
        if v:
            return v
        print("Input cannot be empty. Try again.")


def find_index_by_contact(donors, contact):
    """Find index of donor by contact (unique). Return -1 if not found."""
    for i, d in enumerate(donors):
        if d.get("contact") == contact:
            return i
    return -1


# ------------------ DSA: Sorting ------------------ #
def bubble_sort(donors, key):
    """In-place bubble sort by key (e.g., 'name', 'city', 'blood_group')."""
    n = len(donors)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if str(donors[j].get(key, "")).lower() > str(donors[j + 1].get(key, "")).lower():
                donors[j], donors[j + 1] = donors[j + 1], donors[j]
                swapped = True
        if not swapped:
            break


def insertion_sort(donors, key):
    """In-place insertion sort by key."""
    for i in range(1, len(donors)):
        current = donors[i]
        j = i - 1
        while j >= 0 and str(donors[j].get(key, "")).lower() > str(current.get(key, "")).lower():
            donors[j + 1] = donors[j]
            j -= 1
        donors[j + 1] = current


# ------------------ DSA: Searching ------------------ #
def linear_search(donors, key, value):
    
    value = value.strip().lower()
    results = []
    for d in donors:
        if value in str(d.get(key, "")).lower():
            results.append(d)
    return results


def binary_search_by_key(donors, key, value):
    
    low, high = 0, len(donors) - 1
    value_lower = value.strip().lower()
    found_index = -1
    while low <= high:
        mid = (low + high) // 2
        mid_val = str(donors[mid].get(key, "")).lower()
        if mid_val == value_lower:
            found_index = mid
            break
        elif mid_val < value_lower:
            low = mid + 1
        else:
            high = mid - 1

    if found_index == -1:
        return []

    # expand around found_index to collect all equals
    results = []
    i = found_index
    while i >= 0 and str(donors[i].get(key, "")).lower() == value_lower:
        i -= 1
    i += 1
    while i < len(donors) and str(donors[i].get(key, "")).lower() == value_lower:
        results.append(donors[i])
        i += 1
    return results


# ------------------ Core Operations ------------------ #
def register_donor(donors):
    print("\n--- Register New Donor ---")
    name = input_nonempty("Name: ")
    blood_group = input_nonempty("Blood Group (e.g., A+, O-, B+): ")
    city = input_nonempty("City: ")
    contact = input_nonempty("Contact (unique): ")

    # ensure contact unique
    if find_index_by_contact(donors, contact) != -1:
        print("A donor with this contact already exists.")
        return

    while True:
        last_donation = input_nonempty("Last Donation Date (YYYY-MM-DD) or 'never': ")
        if last_donation.lower() == "never":
            last_donation = "1900-01-01"  # very old date makes them available
            break
        if parse_date(last_donation):
            break
        print("Invalid date format. Please use YYYY-MM-DD or 'never'.")

    donor = {
        "name": name,
        "blood_group": blood_group,
        "city": city,
        "contact": contact,
        "last_donation": last_donation
    }
    donors.append(donor)
    save_donors(donors)
    print("Donor registered successfully.")


def view_all_donors(donors):
    print("\n--- All Donors ---")
    if not donors:
        print("No donors available.")
        return
    for i, d in enumerate(donors):
        pretty_print_donor(d, idx=i)


def edit_donor(donors):
    print("\n--- Edit Donor ---")
    contact = input_nonempty("Enter donor contact to edit: ")
    idx = find_index_by_contact(donors, contact)
    if idx == -1:
        print("Donor not found.")
        return
    donor = donors[idx]
    print("Current details:")
    pretty_print_donor(donor)

    print("Leave blank to keep existing value.")
    name = input("New name: ").strip()
    blood_group = input("New blood group: ").strip()
    city = input("New city: ").strip()
    new_contact = input("New contact: ").strip()
    last_donation = input("New last donation (YYYY-MM-DD or 'never'): ").strip()

    if new_contact and new_contact != contact and find_index_by_contact(donors, new_contact) != -1:
        print("Another donor already uses this contact. Edit aborted.")
        return

    if name:
        donor["name"] = name
    if blood_group:
        donor["blood_group"] = blood_group
    if city:
        donor["city"] = city
    if new_contact:
        donor["contact"] = new_contact
    if last_donation:
        if last_donation.lower() == "never":
            donor["last_donation"] = "1900-01-01"
        elif parse_date(last_donation):
            donor["last_donation"] = last_donation
        else:
            print("Invalid date; keeping old value.")

    donors[idx] = donor
    save_donors(donors)
    print("Donor updated.")


def delete_donor(donors):
    print("\n--- Delete Donor ---")
    contact = input_nonempty("Enter donor contact to delete: ")
    idx = find_index_by_contact(donors, contact)
    if idx == -1:
        print("Donor not found.")
        return
    pretty_print_donor(donors[idx])
    confirm = input("Are you sure you want to delete this donor? (y/n): ").strip().lower()
    if confirm == "y":
        donors.pop(idx)
        save_donors(donors)
        print("Donor deleted.")
    else:
        print("Deletion cancelled.")


def show_statistics(donors):
    print("\n--- Statistics ---")
    total = len(donors)
    print(f"Total donors: {total}")
    by_bg = {}
    by_city = {}
    for d in donors:
        bg = d.get("blood_group", "Unknown")
        city = d.get("city", "Unknown")
        by_bg[bg] = by_bg.get(bg, 0) + 1
        by_city[city] = by_city.get(city, 0) + 1

    print("\nDonors by Blood Group:")
    for k, v in sorted(by_bg.items(), key=lambda x: x[0]):
        print(f"  {k} : {v}")

    print("\nDonors by City:")
    for k, v in sorted(by_city.items(), key=lambda x: x[0]):
        print(f"  {k} : {v}")


# ------------------ Sorting & Search Menus ------------------ #
def sort_menu(donors):
    if not donors:
        print("No donors to sort.")
        return
    print("\n--- Sort Donors ---")
    print("1. By Name (Bubble Sort)")
    print("2. By City (Insertion Sort)")
    print("3. By Blood Group (Bubble Sort)")
    print("4. Custom choice")
    choice = input("Choose option: ").strip()
    if choice == "1":
        bubble_sort(donors, "name")
        print("Sorted by name (bubble sort).")
    elif choice == "2":
        insertion_sort(donors, "city")
        print("Sorted by city (insertion sort).")
    elif choice == "3":
        bubble_sort(donors, "blood_group")
        print("Sorted by blood group (bubble sort).")
    elif choice == "4":
        key = input_nonempty("Sort by which key (name/city/blood_group): ")
        alg = input_nonempty("Algorithm? (bubble/insertion): ").lower()
        if alg == "bubble":
            bubble_sort(donors, key)
            print(f"Sorted by {key} (bubble).")
        elif alg == "insertion":
            insertion_sort(donors, key)
            print(f"Sorted by {key} (insertion).")
        else:
            print("Unknown algorithm.")
    else:
        print("Invalid choice.")
    save_donors(donors)


def user_search_menu(donors):
    if not donors:
        print("No donors available.")
        return
    print("\n--- Search Donor (User) ---")
    print("1. Search by Blood Group")
    print("2. Search by City")
    choice = input("Choose option: ").strip()
    if choice == "1":
        bg = input_nonempty("Enter blood group to search: ")
        # Offer binary search option if list sorted by blood_group
        use_binary = input("Use binary search? (requires list sorted by blood_group) (y/n): ").strip().lower()
        if use_binary == "y":
            results = binary_search_by_key(donors, "blood_group", bg)
            if not results:
                print("No donors found (binary search).")
            else:
                print(f"Found {len(results)} donor(s):")
                for d in results:
                    pretty_print_donor(d)
        else:
            results = linear_search(donors, "blood_group", bg)
            if not results:
                print("No donors found.")
            else:
                for d in results:
                    pretty_print_donor(d)
    elif choice == "2":
        city = input_nonempty("Enter city to search: ")
        results = linear_search(donors, "city", city)
        if not results:
            print("No donors found.")
        else:
            for d in results:
                pretty_print_donor(d)
    else:
        print("Invalid choice.")


def request_blood(donors):
    print("\n--- Request Blood ---")
    bg = input_nonempty("Required Blood Group: ")
    city = input_nonempty("City (leave blank to search all cities): ")
    # First filter by blood group
    matches_bg = linear_search(donors, "blood_group", bg)
    # then filter by city if supplied
    if city:
        matches = [d for d in matches_bg if city.strip().lower() in d.get("city", "").lower()]
    else:
        matches = matches_bg

    # show only available donors (eligible)
    available = [d for d in matches if is_available(d.get("last_donation", ""))]
    not_available = [d for d in matches if not is_available(d.get("last_donation", ""))]

    print(f"\nMatches found: {len(matches)}. Available: {len(available)}")
    if available:
        print("\n--- Available Donors ---")
        for d in available:
            pretty_print_donor(d)
    if not_available:
        print("\n--- Not Yet Eligible Donors ---")
        for d in not_available:
            pretty_print_donor(d)


# ------------------ Admin & User Menus ------------------ #
def admin_dashboard(donors):
    while True:
        print("\n------ ADMIN DASHBOARD ------")
        print("1. Register New Donor")
        print("2. View All Donors")
        print("3. Edit Donor")
        print("4. Delete Donor")
        print("5. Sort Donors")
        print("6. View Statistics")
        print("7. Logout")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            register_donor(donors)
        elif choice == "2":
            view_all_donors(donors)
        elif choice == "3":
            edit_donor(donors)
        elif choice == "4":
            delete_donor(donors)
        elif choice == "5":
            sort_menu(donors)
        elif choice == "6":
            show_statistics(donors)
        elif choice == "7":
            print("Logging out of admin.")
            break
        else:
            print("Invalid choice.")


def user_mode(donors):
    while True:
        print("\n------ USER MODE ------")
        print("1. Search Donor")
        print("2. Sort Donors (view only)")
        print("3. Request Blood (find available donors)")
        print("4. Back to Main Menu")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            user_search_menu(donors)
        elif choice == "2":
            print("Sorting will modify the in-memory order and save results.")
            sort_menu(donors)
            view_all_donors(donors)
        elif choice == "3":
            request_blood(donors)
        elif choice == "4":
            break
        else:
            print("Invalid choice.")


# ------------------ Main Program ------------------ #
def main():
    donors = load_donors()
    print("======Smart Blood Donor & Request Management System========")
    while True:
        print("\n=============================")
        print("1. Admin Login")
        print("2. User Mode")
        print("3. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            pwd = input("Enter admin password: ").strip()
            if pwd == ADMIN_PASSWORD:
                print("Admin login successful.")
                admin_dashboard(donors)
            else:
                print("Incorrect password.")
        elif choice == "2":
            user_mode(donors)
        elif choice == "3":
            print("Saving data and exiting...")
            save_donors(donors)
            print("Goodbye")
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
