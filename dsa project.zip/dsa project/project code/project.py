import json
import os
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

DATA_FILE = "donors.json"
ADMIN_PASSWORD = "admin123"
ELIGIBLE_DAYS = 30  # donor available if last donation was >= 30 days


# ------------------ File Handling ------------------ #
def load_donors(filename=DATA_FILE):
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
            if not isinstance(data, list):
                return []
            return data
    except (json.JSONDecodeError, IOError):
        return []


def save_donors(donors, filename=DATA_FILE):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(donors, f, indent=4)
    except IOError as e:
        messagebox.showerror("Error", f"Error saving donors: {e}")


# ------------------ Utility Helpers ------------------ #
def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    except Exception:
        return None


def is_available(last_donation_str):
    d = parse_date(last_donation_str)
    if not d:
        return False
    return (datetime.today().date() - d) >= timedelta(days=ELIGIBLE_DAYS)


def find_index_by_contact(donors, contact):
    for i, d in enumerate(donors):
        if d.get("contact") == contact:
            return i
    return -1


# ------------------ DSA: Sorting ------------------ #
def bubble_sort(donors, key):
    n = len(donors)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if str(donors[j].get(key, "")).lower() > str(donors[j + 1].get(key, "")).lower():
                donors[j], donors[j + 1] = donors[j + 1], donors[j]
                swapped = True
        if not swapped:
            break


def insertion_sort(donors, key):
    for i in range(1, len(donors)):
        current = donors[i]
        j = i - 1
        while j >= 0 and str(donors[j].get(key, "")).lower() > str(current.get(key, "")).lower():
            donors[j + 1] = donors[j]
            j -= 1
        donors[j + 1] = current


# ------------------ DSA: Searching ------------------ #
def linear_search(donors, key, value):
    value = value.strip().lower()
    results = []
    for d in donors:
        if value in str(d.get(key, "")).lower():
            results.append(d)
    return results


def binary_search_by_key(donors, key, value):
   
    value_lower = value.strip().lower()
    low, high = 0, len(donors) - 1
    found_index = -1
    while low <= high:
        mid = (low + high) // 2
        mid_val = str(donors[mid].get(key, "")).lower()
        if mid_val == value_lower:
            found_index = mid
            break
        elif mid_val < value_lower:
            low = mid + 1
        else:
            high = mid - 1

    if found_index == -1:
        return []

    # expand left & right
    results = []
    i = found_index
    while i >= 0 and str(donors[i].get(key, "")).lower() == value_lower:
        i -= 1
    i += 1
    while i < len(donors) and str(donors[i].get(key, "")).lower() == value_lower:
        results.append(donors[i])
        i += 1
    return results


# ------------------ GUI App ------------------ #
class SmartBloodDonorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Blood Donor & Request Management System")
        self.root.geometry("1000x620")
        self.root.config(bg="#f8f8f8")

        self.donors = load_donors()
        self.build_main_screen()

    # ---------- main screen ---------- #
    def build_main_screen(self):
        self.clear()
        tk.Label(self.root, text="SMART BLOOD DONOR & REQUEST MANAGEMENT SYSTEM",
                 font=("Helvetica", 18, "bold"), bg="#f8f8f8", fg="#a80000").pack(pady=30)

        btn_frame = tk.Frame(self.root, bg="#f8f8f8")
        btn_frame.pack(pady=30)

        tk.Button(btn_frame, text="Admin Login", width=28, height=2, bg="#a80000", fg="white",
                  command=self.admin_login).grid(row=0, column=0, padx=20, pady=10)
        tk.Button(btn_frame, text="User Mode", width=28, height=2, bg="#007acc", fg="white",
                  command=self.user_menu).grid(row=0, column=1, padx=20, pady=10)
        tk.Button(btn_frame, text="Exit", width=28, height=2, bg="#444444", fg="white",
                  command=self.on_exit).grid(row=1, column=0, columnspan=2, pady=10)

        footer = tk.Label(self.root, text="Developed using Python (Tkinter) | Data stored in donors.json",
                          bg="#f8f8f8", font=("Arial", 10))
        footer.pack(side="bottom", pady=10)

    def on_exit(self):
        save_donors(self.donors)
        self.root.quit()

    # ---------- admin login ---------- #
    def admin_login(self):
        pwd = simpledialog.askstring("Admin Login", "Enter admin password:", show="*")
        if pwd == ADMIN_PASSWORD:
            messagebox.showinfo("Login", "Admin login successful.")
            self.admin_dashboard()
        else:
            messagebox.showerror("Error", "Incorrect password.")

    # ---------- admin dashboard ---------- #
    def admin_dashboard(self):
        self.clear()
        tk.Label(self.root, text="Admin Dashboard", font=("Helvetica", 16, "bold"),
                 bg="#f8f8f8", fg="#a80000").pack(pady=15)

        frame = tk.Frame(self.root, bg="#f8f8f8")
        frame.pack(pady=10)

        buttons = [
            ("Register New Donor", self.popup_register),
            ("View All Donors", self.popup_view_all),
            ("Edit Donor", self.popup_edit),
            ("Delete Donor", self.popup_delete),
            ("Sort Donors", self.popup_sort),
            ("View Statistics", self.popup_statistics),
            ("Logout", self.build_main_screen)
        ]

        for i, (text, cmd) in enumerate(buttons):
            tk.Button(frame, text=text, width=28, height=2, bg="#a80000", fg="white",
                      command=cmd).grid(row=i // 2, column=i % 2, padx=10, pady=8)

    # ---------- user menu ---------- #
    def user_menu(self):
        self.clear()
        tk.Label(self.root, text="User Mode", font=("Helvetica", 16, "bold"),
                 bg="#f8f8f8", fg="#007acc").pack(pady=15)

        frame = tk.Frame(self.root, bg="#f8f8f8")
        frame.pack(pady=10)

        buttons = [
            ("Search Donor", self.popup_search),
            ("Sort Donors", self.popup_sort_user),  # user sort option (matches CLI)
            ("Request Blood", self.popup_request),
            ("Back to Main Menu", self.build_main_screen)
        ]

        for i, (text, cmd) in enumerate(buttons):
            tk.Button(frame, text=text, width=28, height=2, bg="#007acc" if i < 3 else "#444444", fg="white",
                      command=cmd).grid(row=i, column=0, padx=12, pady=8)

    # ---------- reusable table popup ---------- #
    def popup_table(self, title, donors_list):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("930x420")

        cols = ("Name", "Blood Group", "City", "Contact", "Last Donation", "Status")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=145, anchor="center")
        vsb = ttk.Scrollbar(win, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        for d in donors_list:
            status = "AVAILABLE" if is_available(d.get("last_donation", "")) else "NOT AVAILABLE"
            tree.insert("", "end", values=(d.get("name", ""), d.get("blood_group", ""), d.get("city", ""),
                                           d.get("contact", ""), d.get("last_donation", ""), status))
        return win, tree

    # ---------------- Admin popups ---------------- #
    def popup_register(self):
        win = tk.Toplevel(self.root)
        win.title("Register New Donor")
        win.geometry("420x380")

        labels = ["Name", "Blood Group", "City", "Contact", "Last Donation (YYYY-MM-DD or never)"]
        entries = {}
        for i, lab in enumerate(labels):
            tk.Label(win, text=lab).grid(row=i, column=0, padx=10, pady=8, sticky="w")
            e = tk.Entry(win, width=30)
            e.grid(row=i, column=1, padx=10, pady=8)
            entries[lab] = e

        def save_action():
            name = entries["Name"].get().strip()
            bg = entries["Blood Group"].get().strip()
            city = entries["City"].get().strip()
            contact = entries["Contact"].get().strip()
            last = entries["Last Donation (YYYY-MM-DD or never)"].get().strip()

            if not (name and bg and city and contact):
                messagebox.showerror("Error", "All fields are required (except last donation can be 'never').")
                return
            if find_index_by_contact(self.donors, contact) != -1:
                messagebox.showerror("Error", "Contact already exists.")
                return
            if last.lower() == "never" or last == "":
                last = "1900-01-01"
            elif not parse_date(last):
                messagebox.showerror("Error", "Invalid date format. Use YYYY-MM-DD or 'never'.")
                return

            donor = {"name": name, "blood_group": bg, "city": city, "contact": contact, "last_donation": last}
            self.donors.append(donor)
            save_donors(self.donors)
            messagebox.showinfo("Saved", "Donor registered successfully.")
            win.destroy()

        tk.Button(win, text="Save Donor", bg="#a80000", fg="white", command=save_action).grid(row=len(labels), column=1,
                                                                                              pady=12)

    def popup_view_all(self):
        if not self.donors:
            messagebox.showinfo("Info", "No donors available.")
            return
        self.popup_table("All Donors", self.donors)

    def popup_edit(self):
        contact = simpledialog.askstring("Edit Donor", "Enter contact number of donor to edit:")
        if not contact:
            return
        idx = find_index_by_contact(self.donors, contact)
        if idx == -1:
            messagebox.showerror("Error", "Donor not found.")
            return
        donor = self.donors[idx]
        win = tk.Toplevel(self.root)
        win.title("Edit Donor")
        win.geometry("420x320")

        labels = ["Name", "Blood Group", "City", "Contact", "Last Donation (YYYY-MM-DD or never)"]
        entries = {}
        initial = [donor.get("name", ""), donor.get("blood_group", ""), donor.get("city", ""),
                   donor.get("contact", ""), donor.get("last_donation", "1900-01-01")]
        for i, lab in enumerate(labels):
            tk.Label(win, text=lab).grid(row=i, column=0, padx=10, pady=6, sticky="w")
            e = tk.Entry(win, width=30)
            e.grid(row=i, column=1, padx=10, pady=6)
            e.insert(0, initial[i])
            entries[lab] = e

        def save_edit():
            new_name = entries["Name"].get().strip()
            new_bg = entries["Blood Group"].get().strip()
            new_city = entries["City"].get().strip()
            new_contact = entries["Contact"].get().strip()
            new_last = entries["Last Donation (YYYY-MM-DD or never)"].get().strip()

            if new_contact != donor["contact"] and find_index_by_contact(self.donors, new_contact) != -1:
                messagebox.showerror("Error", "Another donor uses this contact.")
                return
            if new_last.lower() == "never" or new_last == "":
                new_last = "1900-01-01"
            elif not parse_date(new_last):
                messagebox.showerror("Error", "Invalid date format.")
                return

            donor.update({"name": new_name, "blood_group": new_bg, "city": new_city,
                          "contact": new_contact, "last_donation": new_last})
            self.donors[idx] = donor
            save_donors(self.donors)
            messagebox.showinfo("Updated", "Donor updated successfully.")
            win.destroy()

        tk.Button(win, text="Save Changes", bg="#a80000", fg="white", command=save_edit).grid(row=len(labels), column=1,
                                                                                               pady=12)

    def popup_delete(self):
        contact = simpledialog.askstring("Delete Donor", "Enter contact number of donor to delete:")
        if not contact:
            return
        idx = find_index_by_contact(self.donors, contact)
        if idx == -1:
            messagebox.showerror("Error", "Donor not found.")
            return
        donor = self.donors[idx]
        confirm = messagebox.askyesno("Confirm Delete",
                                      f"Delete donor {donor.get('name')} (Contact: {donor.get('contact')})?")
        if confirm:
            self.donors.pop(idx)
            save_donors(self.donors)
            messagebox.showinfo("Deleted", "Donor deleted successfully.")

    def popup_sort(self):
        """
        Admin sort: choose key and algorithm; modifies list and saves it (like CLI).
        """
        win = tk.Toplevel(self.root)
        win.title("Sort Donors (Admin)")
        win.geometry("360x200")

        tk.Label(win, text="Sort by (name / city / blood_group):").pack(pady=8)
        key_entry = tk.Entry(win, width=30)
        key_entry.pack()

        tk.Label(win, text="Algorithm (bubble / insertion):").pack(pady=8)
        alg_entry = tk.Entry(win, width=30)
        alg_entry.pack()

        def do_sort():
            key = key_entry.get().strip()
            alg = alg_entry.get().strip().lower()
            if not key or alg not in ("bubble", "insertion"):
                messagebox.showerror("Error", "Provide valid key and algorithm.")
                return
            if alg == "bubble":
                bubble_sort(self.donors, key)
            else:
                insertion_sort(self.donors, key)
            save_donors(self.donors)
            messagebox.showinfo("Sorted", f"Donors sorted by {key} using {alg} sort.")
            win.destroy()
            self.popup_table(f"Sorted by {key} ({alg})", self.donors)

        tk.Button(win, text="Sort", bg="#a80000", fg="white", command=do_sort).pack(pady=12)

    def popup_statistics(self):
        total = len(self.donors)
        by_bg = {}
        by_city = {}
        for d in self.donors:
            bg = d.get("blood_group", "Unknown")
            city = d.get("city", "Unknown")
            by_bg[bg] = by_bg.get(bg, 0) + 1
            by_city[city] = by_city.get(city, 0) + 1

        msg = f"Total Donors: {total}\n\nDonors by Blood Group:\n"
        for k, v in sorted(by_bg.items(), key=lambda x: x[0]):
            msg += f"  {k} : {v}\n"
        msg += "\nDonors by City:\n"
        for k, v in sorted(by_city.items(), key=lambda x: x[0]):
            msg += f"  {k} : {v}\n"
        messagebox.showinfo("Statistics", msg)

    # ---------------- User popups ---------------- #
    def popup_search(self):
        win = tk.Toplevel(self.root)
        win.title("Search Donor")
        win.geometry("420x250")

        tk.Label(win, text="Search by (use one or both fields):").pack(pady=6)
        tk.Label(win, text="Blood Group (exact or partial):").pack(pady=4)
        bg_e = tk.Entry(win, width=30)
        bg_e.pack()
        tk.Label(win, text="City (exact or partial):").pack(pady=4)
        city_e = tk.Entry(win, width=30)
        city_e.pack()

        def do_search():
            bg = bg_e.get().strip()
            city = city_e.get().strip()
            # Provide option for binary search if bg provided
            use_bin = False
            if bg:
                ans = messagebox.askyesno("Binary Search", "Use binary search for blood group? (list must be sorted by blood_group)")
                use_bin = ans
            results = []
            if bg and use_bin:
                # ensure sorted by blood_group
                bubble_sort(self.donors, "blood_group")
                save_donors(self.donors)  # optional - follow CLI behavior to save after sort
                results = binary_search_by_key(self.donors, "blood_group", bg)
            else:
                # linear search: combine bg and city filters
                results = [d for d in self.donors if
                           (not bg or bg.lower() in d.get("blood_group", "").lower()) and
                           (not city or city.lower() in d.get("city", "").lower())]
            if results:
                self.popup_table("Search Results", results)
            else:
                messagebox.showinfo("No results", "No donors found matching criteria.")

        tk.Button(win, text="Search", bg="#007acc", fg="white", command=do_search).pack(pady=12)

    def popup_sort_user(self):
        """
        User can also sort (like CLI). Sorting modifies in-memory order and saves it.
        """
        win = tk.Toplevel(self.root)
        win.title("Sort Donors (User)")
        win.geometry("360x200")

        tk.Label(win, text="Sort by (name / city / blood_group):").pack(pady=8)
        key_entry = tk.Entry(win, width=30)
        key_entry.pack()

        tk.Label(win, text="Algorithm (bubble / insertion):").pack(pady=8)
        alg_entry = tk.Entry(win, width=30)
        alg_entry.pack()

        def do_sort_user():
            key = key_entry.get().strip()
            alg = alg_entry.get().strip().lower()
            if not key or alg not in ("bubble", "insertion"):
                messagebox.showerror("Error", "Provide valid key and algorithm.")
                return
            if alg == "bubble":
                bubble_sort(self.donors, key)
            else:
                insertion_sort(self.donors, key)
            save_donors(self.donors)
            messagebox.showinfo("Sorted", f"Donors sorted by {key} using {alg} sort.")
            win.destroy()
            self.popup_table(f"Sorted by {key} ({alg})", self.donors)

        tk.Button(win, text="Sort", bg="#007acc", fg="white", command=do_sort_user).pack(pady=12)

    def popup_request(self):
        win = tk.Toplevel(self.root)
        win.title("Request Blood")
        win.geometry("420x240")

        tk.Label(win, text="Required Blood Group:").pack(pady=6)
        bg_e = tk.Entry(win, width=30)
        bg_e.pack()
        tk.Label(win, text="City (leave blank to search all cities):").pack(pady=6)
        city_e = tk.Entry(win, width=30)
        city_e.pack()

        def do_request():
            bg = bg_e.get().strip()
            city = city_e.get().strip()
            if not bg:
                messagebox.showerror("Error", "Blood group is required.")
                return
            matches_bg = linear_search(self.donors, "blood_group", bg)
            if city:
                matches = [d for d in matches_bg if city.lower() in d.get("city", "").lower()]
            else:
                matches = matches_bg
            available = [d for d in matches if is_available(d.get("last_donation", ""))]
            not_available = [d for d in matches if not is_available(d.get("last_donation", ""))]

            # show counts and open table for available (and optionally not available)
            msg = f"Matches found: {len(matches)}\nAvailable: {len(available)}\nNot eligible yet: {len(not_available)}"
            messagebox.showinfo("Request Results", msg)
            if available:
                self.popup_table("Available Donors", available)
            if not_available:
                if messagebox.askyesno("Show not eligible?", "Show donors who are not yet eligible?"):
                    self.popup_table("Not Yet Eligible Donors", not_available)

        tk.Button(win, text="Find Donors", bg="#007acc", fg="white", command=do_request).pack(pady=12)

    # ---------- utility ---------- #
    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()


# ------------------ Run App ------------------ #
if __name__ == "__main__":
    root = tk.Tk()
    app = SmartBloodDonorApp(root)
    root.mainloop()
